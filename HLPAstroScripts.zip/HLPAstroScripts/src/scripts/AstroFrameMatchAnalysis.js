#feature-id   AstroFrameMatchAnalysis : HLP > AstroFrame Match Analysis
#feature-info This script measures and compares light frames and related calibration frames in their related pairs to ensure all necessary components match each other.

#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/Sizer.jsh>

// Function to force refresh of the label
function forceLabelRefresh(label) {
    label.visible = false;
    label.update();
    label.visible = true;
    label.update();
}

// Function to get appropriate labels based on selection type
function getLabels(selectedOption) {
    if (selectedOption === 1) {
        // Lights / Darks selected
        return ["Lights", "Darks"];
    } else if (selectedOption === 2) {
        // Flats / Flat Darks selected
        return ["Flats", "Flat Darks"];
    } else {
        // Default: Darks / Flat Darks
        return ["Darks", "Flat Darks"];
    }
}

// Function to calculate the mean brightness of a set of images
function getMeanBrightness(imageFiles) {
    if (imageFiles.length === 0) {
        return 0;
    }

    let totalMean = 0;
    let filesProcessed = 0;

    imageFiles.forEach(file => {
        let imgWindow = ImageWindow.open(file)[0];
        if (imgWindow) {
            let mean = imgWindow.mainView.computeOrFetchProperty("Mean");
            let normalizedMean = mean.at(0); // Assuming single-channel or grayscale images
            let bitDepth = 16; // Assuming 16-bit images
            let meanValue = normalizedMean * (Math.pow(2, bitDepth) - 1); // Convert normalized mean to 16-bit scale
            totalMean += meanValue;
            filesProcessed++;
            imgWindow.forceClose();
        } else {
            console.warning("Unable to open image for brightness calculation: " + file);
        }
    });

    console.writeln("Processed " + filesProcessed + " files for mean brightness.");
    return totalMean / filesProcessed;
}

function AstroDarkAnalysisDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.darks = [];
    this.flatDarks = [];

    // Dropdown for selection type
this.frameTypeLabel = new Label(this);
this.frameTypeLabel.text = "Please select your frame type:";
this.frameTypeLabel.textAlignment = TextAlign_Left;
this.frameTypeLabel.margin = 4;
    this.selectionTypeComboBox = new ComboBox(this);
    this.selectionTypeComboBox.addItem("Darks / Flat Darks");
    this.selectionTypeComboBox.addItem("Lights / Darks");
    this.selectionTypeComboBox.addItem("Flats / Flat Darks");
    this.selectionTypeComboBox.onItemSelected = function (index) {
        this.selectedOption = index;

        // Update button labels based on selection type
        if (index === 1) { // Lights / Darks selected
            this.selectDarksButton.text = "Select Lights";
            this.selectFlatDarksButton.text = "Select Darks";
        } else if (index === 2) { // Flats / Flat Darks selected
            this.selectDarksButton.text = "Select Flats";
            this.selectFlatDarksButton.text = "Select Flat Darks";
        } else { // Default Darks / Flat Darks
            this.selectDarksButton.text = "Select Darks";
            this.selectFlatDarksButton.text = "Select Flat Darks";
        }

        console.writeln("Selected option: " + this.selectionTypeComboBox.itemText(index));
    }.bind(this);
    this.selectedOption = 0; // Default to "Darks / Flat Darks"

    // Title Label with Bigger Font
    this.titleLabel = new Label(this);
    this.titleLabel.text = "AstroFrame Match Analysis";
    this.titleLabel.font = new Font("SansSerif", 20);
    this.titleLabel.textAlignment = TextAlign_Center;

    // Instruction Area with a Visible Box
    this.instructionGroupBox = new GroupBox(this);
    this.instructionGroupBox.title = "Instructions";
    this.instructionGroupBox.sizer = new VerticalSizer;
    this.instructionGroupBox.sizer.margin = 6;
    this.instructionGroupBox.sizer.spacing = 4;

    // Instruction Label with Smaller Font
    this.instructionLabel = new Label(this.instructionGroupBox);
    this.instructionLabel.font = new Font("SansSerif", 14);
    this.instructionLabel.text = "To minimize potential issues during processing, it is important to utilize a matching set of frames.\n" +
    "This script will analyze the frame sets for matching Gain, Offset, Temperature and Mean Brightness or Exposure.\n\n" +
        "Instructions:\n" +
        "Select the frame type you want to analyze from the drop down menu:\n" +
        "Use the \"Select\" buttons to upload your frames and click analyze.\n\n" +
        "Important notes:\n" +
        "Mean Brightness will be measured for Darks / Flat Darks only and Exposure is measured for Lights / Darks and Flats / Flat Darks\n" +
        "The script has a 1.5% tolerance built in for mean brightness, however, differences might be good to investigate.\n\n" +
    "Possible causes of mean differences:\n" +
    "- Light leaks (Capturing darks inside a dark room vs capturing flat darks outside under a streetlight for example)\n" +
    "- Acquisition software differences (All frames should be captured with the same acquisition software, like NINA for example)\n" +
    "- Age of darks (if using a dark library, darks may need to be redone every 6 months)\n\n" +
    "Written by Tony De Nardo";
    this.instructionLabel.textAlignment = TextAlign_Center;
    this.instructionGroupBox.sizer.add(this.instructionLabel);

    // Select Darks Button
    this.selectDarksButton = new PushButton(this);
    this.selectDarksButton.text = "Select Darks";
    this.selectDarksButton.maxWidth = 200;
    this.selectDarksButton.onClick = function () {
        let selectedFiles = selectImages();
        if (selectedFiles.length > 0) {
            this.darks = selectedFiles;
            this.statusLabel.text = "Selected " + selectedFiles.length + " frames.";
        } else {
            this.statusLabel.text = "No frames selected.";
        }
        this.updateSelectionCount();
    }.bind(this);

    // Select Flat Darks Button
    this.selectFlatDarksButton = new PushButton(this);
    this.selectFlatDarksButton.text = "Select Flat Darks";
    this.selectFlatDarksButton.maxWidth = 200;
    this.selectFlatDarksButton.onClick = function () {
        let selectedFiles = selectImages();
        if (selectedFiles.length > 0) {
            this.flatDarks = selectedFiles;
            this.statusLabel.text = "Selected " + selectedFiles.length + " frames.";
        } else {
            this.statusLabel.text = "No frames selected.";
        }
        this.updateSelectionCount();
    }.bind(this);

// Analyze Button
this.analyzeButton = new PushButton(this);
this.analyzeButton.text = "Analyze Frames";
this.analyzeButton.maxWidth = 200;
this.analyzeButton.onClick = function () {
    if (this.darks.length > 0 && this.flatDarks.length > 0) {
        // Get appropriate labels
        let [label1, label2] = getLabels(this.selectedOption);

        // Initialize variables for mean brightness
        let darkMean = 0;
        let flatDarkMean = 0;

        // Get metadata for all files
        let darkMetadata = getMetadata(this.darks, label1);
        let flatDarkMetadata = getMetadata(this.flatDarks, label2);

        if (darkMetadata === null || flatDarkMetadata === null) {
            this.resultLabel.text = "Error: Unable to retrieve metadata from selected frames.";
            this.resultLabel.textColor = 0xFF0000; // Red for error
            return;
        }

        let match = true;
        let mismatchDetails = [];

        // Compare Gain
        if (darkMetadata.gain !== flatDarkMetadata.gain) {
            match = false;
            mismatchDetails.push(label1 + " Gain (" + darkMetadata.gain + ") vs " + label2 + " Gain (" + flatDarkMetadata.gain + ")");
        }

        // Compare Offset
        if (darkMetadata.offset !== flatDarkMetadata.offset) {
            match = false;
            mismatchDetails.push(label1 + " Offset (" + darkMetadata.offset + ") vs " + label2 + " Offset (" + flatDarkMetadata.offset + ")");
        }

        // Compare Temperature
        if (Math.abs(darkMetadata.temperature - flatDarkMetadata.temperature) > 0.5) {
            match = false;
            mismatchDetails.push(label1 + " Temperature (" + darkMetadata.temperature + "°C) vs " + label2 + " Temperature (" + flatDarkMetadata.temperature + "°C)");
        }

        // Conditional: Exposure or Mean Brightness
        if (this.selectedOption === 1 || this.selectedOption === 2) {
            if (darkMetadata.exposure !== flatDarkMetadata.exposure) {
                match = false;
                mismatchDetails.push(label1 + " Exposure Time (" + darkMetadata.exposure + "s) vs " + label2 + " Exposure Time (" + flatDarkMetadata.exposure + "s)");
            }
        } else {
            // Calculate Mean Brightness for Darks/Flat Darks
            darkMean = getMeanBrightness(this.darks);
            flatDarkMean = getMeanBrightness(this.flatDarks);
            let tolerance = 0.015 * darkMean;
            if (Math.abs(darkMean - flatDarkMean) > tolerance) {
                match = false;
                mismatchDetails.push(label1 + " Mean Brightness (" + darkMean.toFixed(2) + ") vs " + label2 + " Mean Brightness (" + flatDarkMean.toFixed(2) + ")");
            }
        }

        // Display Results
        if (match) {
            this.resultLabel.text = "MATCH!\n" +
                "Gain: " + label1 + " (" + darkMetadata.gain + ") vs " + label2 + " (" + flatDarkMetadata.gain + ")\n" +
                "Offset: " + label1 + " (" + darkMetadata.offset + ") vs " + label2 + " (" + flatDarkMetadata.offset + ")\n" +
                "Temperature (+/- 0.5°C): " + label1 + " (" + darkMetadata.temperature + "°C) vs " + label2 + " (" + flatDarkMetadata.temperature + "°C)\n";

            if (this.selectedOption === 1 || this.selectedOption === 2) {
                this.resultLabel.text += "Exposure Time: " + label1 + " (" + darkMetadata.exposure + "s) vs " + label2 + " (" + flatDarkMetadata.exposure + "s)";
            } else {
                this.resultLabel.text += "Mean Brightness (+/- 1.5%): " + label1 + " (" + darkMean.toFixed(2) + ") vs " + label2 + " (" + flatDarkMean.toFixed(2) + ")";
            }

            this.resultLabel.textAlignment = TextAlign_Center;
            this.resultLabel.font = new Font("SansSerif", 20);
            this.resultLabel.textColor = 0x00CC00; // Green for match
        } else {
            this.resultLabel.text = "MISMATCH!\n" + mismatchDetails.join("\n");
            this.resultLabel.textAlignment = TextAlign_Center;
            this.resultLabel.font = new Font("SansSerif", 20);
            this.resultLabel.textColor = 0xFF0000; // Red for mismatch
        }

        forceLabelRefresh(this.resultLabel);
    } else {
        this.resultLabel.text = "Please select both sets of frames for analysis.";
        this.resultLabel.textAlignment = TextAlign_Center;
        this.resultLabel.font = new Font("SansSerif", 12);
        this.resultLabel.textColor = 0x000000; // Black for instructions
    }
}.bind(this);

    // Clear Button
    this.clearButton = new PushButton(this);
    this.clearButton.text = "Clear";
    this.clearButton.maxWidth = 200;
    this.clearButton.onClick = function () {
        this.darks = [];
        this.flatDarks = [];
        this.statusLabel.text = "";
        this.selectionCountLabel.text = "";
        this.resultLabel.text = "";
    }.bind(this);

    // Status Label
    this.statusLabel = new Label(this);
    this.statusLabel.text = "";
    this.statusLabel.textAlignment = TextAlign_Center;

    // Selection Count Label
    this.selectionCountLabel = new Label(this);
    this.selectionCountLabel.text = "";
    this.selectionCountLabel.textAlignment = TextAlign_Center;

    // Result Group Box
    this.resultGroupBox = new GroupBox(this);
    this.resultGroupBox.title = "Analysis Results";
    this.resultGroupBox.sizer = new VerticalSizer;
    this.resultGroupBox.sizer.margin = 6;
    this.resultGroupBox.sizer.spacing = 4;

    // Result Label
    this.resultLabel = new Label(this.resultGroupBox);
    this.resultLabel.text = "";
    this.resultLabel.textAlignment = TextAlign_Center;
    this.resultGroupBox.sizer.add(this.resultLabel);

   this.updateSelectionCount = function () {
    if (this.selectedOption === 1) {
        // Lights / Darks selected
        this.selectionCountLabel.text = "Lights selected: " + this.darks.length + " | Darks selected: " + this.flatDarks.length;
    } else if (this.selectedOption === 2) {
        // Flats / Flat Darks selected
        this.selectionCountLabel.text = "Flats selected: " + this.darks.length + " | Flat Darks selected: " + this.flatDarks.length;
    } else {
        // Default or Darks / Flat Darks
        this.selectionCountLabel.text = "Darks selected: " + this.darks.length + " | Flat Darks selected: " + this.flatDarks.length;
    }
}.bind(this);

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 4;

    this.sizer.add(this.titleLabel);
    this.sizer.addSpacing(8);
    this.sizer.add(this.instructionGroupBox);
    this.sizer.addSpacing(8);

   // Label and Dropdown Position
let dropdownSizer = new HorizontalSizer;
dropdownSizer.spacing = 6; // Space between label and dropdown
dropdownSizer.addStretch();
dropdownSizer.add(this.frameTypeLabel);
dropdownSizer.add(this.selectionTypeComboBox);
dropdownSizer.addStretch();
this.sizer.add(dropdownSizer);
    this.sizer.addSpacing(8);

    let mainSizer = new HorizontalSizer;
    mainSizer.spacing = 12;

    // Left Side (Buttons and Labels)
    let leftSizer = new VerticalSizer;
    leftSizer.spacing = 4;
    leftSizer.add(this.selectDarksButton);
    leftSizer.addSpacing(4);
    leftSizer.add(this.selectFlatDarksButton);
    leftSizer.addSpacing(4);
    leftSizer.add(this.analyzeButton);
    leftSizer.addSpacing(4);
    leftSizer.add(this.clearButton);
    leftSizer.addSpacing(8);
    leftSizer.add(this.statusLabel);
    leftSizer.add(this.selectionCountLabel);

    // Add Left Side and Result Box to Main Sizer
    mainSizer.add(leftSizer);
    mainSizer.add(this.resultGroupBox, 100);

    this.sizer.add(mainSizer);
    this.windowTitle = "AstroFrame Match Analysis";
}
AstroDarkAnalysisDialog.prototype = new Dialog;

// Function to select images
function selectImages() {
    let dialog = new OpenFileDialog();
    dialog.multipleSelections = true;
    dialog.caption = "Select Image Files";
    dialog.filters = [["FITS Images", "*.fit *.fits"], ["All Files", "*.*"]];
    return dialog.execute() ? dialog.fileNames : [];
}

// Function to extract metadata from a set of images
function getMetadata(imageFiles, label) {
    if (imageFiles.length === 0) {
        return null;
    }

    let metadata = {
        gain: null,
        offset: null,
        temperature: null,
        exposure: null, // Adding exposure property
        filesProcessed: 0
    };

    imageFiles.forEach(file => {
        let window = ImageWindow.open(file)[0];
        if (window) {
            let keywords = window.keywords;

            console.writeln("Extracting metadata for: " + label);
            keywords.forEach(keyword => {
                console.writeln("Keyword: " + keyword.name + " = " + keyword.value);
                if (keyword.name === "GAIN") {
                    if (metadata.gain === null) metadata.gain = parseFloat(keyword.value);
                    else if (metadata.gain !== parseFloat(keyword.value)) console.warning("Inconsistent Gain in file: " + file);
                } else if (keyword.name === "OFFSET") {
                    if (metadata.offset === null) metadata.offset = parseFloat(keyword.value);
                    else if (metadata.offset !== parseFloat(keyword.value)) console.warning("Inconsistent Offset in file: " + file);
                } else if (keyword.name === "CCD-TEMP") {
                    if (metadata.temperature === null) metadata.temperature = parseFloat(keyword.value);
                    else if (Math.abs(metadata.temperature - parseFloat(keyword.value)) > 0.5) console.warning("Inconsistent Temperature in file: " + file);
                } else if (keyword.name === "EXPTIME" || keyword.name === "EXPOSURE") {
                    if (metadata.exposure === null) metadata.exposure = parseFloat(keyword.value);
                    else if (metadata.exposure !== parseFloat(keyword.value)) console.warning("Inconsistent Exposure in file: " + file);
                }
            });

            metadata.filesProcessed++;
            window.forceClose();
        } else {
            console.warning("Unable to open image: " + file);
        }
    });

    console.writeln(label + " metadata processed: " + metadata.filesProcessed + " files.");
    return metadata;
}

function main() {
    let dialog = new AstroDarkAnalysisDialog();
    dialog.execute();
}

main();
