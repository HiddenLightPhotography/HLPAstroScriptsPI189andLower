#feature-id   AstroImageDetail : HLP > Astro Image Detail
#feature-info This script performs a stretch of a linear star image, boosts color, and removes any green cast.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>

// include constants
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#ifeq __PI_PLATFORM__ MACOSX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.mlpackage"
#endif
#ifeq __PI_PLATFORM__ MSWINDOWS
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.pb"
#endif
#ifeq __PI_PLATFORM__ LINUX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.pb"
#endif

// define a global variable containing the script's parameters
var AstroImageDetailParameters = {
   LargeScale: 5,
   SmallScale: 1,
   showPreview: false,
   targetView: undefined,
   applyNoiseXTerminator: false,
   denoise: 0.50, // Default value for denoise
   save: function () {
      console.noteln("Saving parameters...");
      Parameters.set("LargeScale", this.LargeScale);
      Parameters.set("SmallScale", this.SmallScale);
      Parameters.set("showPreview", this.showPreview);
      Parameters.set("applyNoiseXTerminator", this.applyNoiseXTerminator);
      Parameters.set("denoise", this.denoise); // Save denoise value
      console.noteln("Parameters saved successfully.");
   },
   load: function () {
      console.noteln("Loading parameters...");
      if (Parameters.has("LargeScale")) this.LargeScale = Parameters.getReal("LargeScale");
      if (Parameters.has("SmallScale")) this.SmallScale = Parameters.getReal("SmallScale");
      if (Parameters.has("showPreview")) this.showPreview = Parameters.getBoolean("showPreview");
      if (Parameters.has("applyNoiseXTerminator")) this.applyNoiseXTerminator = Parameters.getBoolean("applyNoiseXTerminator");
      if (Parameters.has("denoise")) this.denoise = Parameters.getReal("denoise");
      console.noteln("Parameters loaded successfully.");
   },
};

// ScrollControl class definition
function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

// Global function to proportionally scale MLT layers
function getScaledLayers(scale) {
   const defaultLayers = [0.000, 0.100, 0.075, 0.050, 0.025, 0.000];
   return defaultLayers.map((bias) => bias * (scale / 5));
}

// Apply MLT to a view with the scaled layers
function applyMLT(view, scale) {
   let scaledLayers = getScaledLayers(scale);

   var P = new MultiscaleLinearTransform;
   P.layers = [
      [true, true, scaledLayers[0], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[1], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[2], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[3], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[4], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[5], false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.prototype.StarletTransform;
   P.executeOn(view);
}

// Apply MMT to a view with the scaled layers
function applyMMT(view, scale) {
   let scaledLayers = getScaledLayers(scale); // Use the same proportional scaling

   var P = new MultiscaleMedianTransform;
   P.layers = [
      [true, true, scaledLayers[0], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[1], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[2], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[3], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[4], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[5], false, 1.0000, 1.00, 0.0000]
   ];
   P.medianWaveletThreshold = 5.00; // Threshold remains fixed
   P.executeOn(view);
}

// Apply NoiseXTerminator to a target view
function applyNoiseXTerminator(view, denoise) {
    console.noteln("Starting NoiseXTerminator process...");
    try {
        let P = new NoiseXTerminator();
        P.ai_file = NOISEXTERMINATOR_AI_FILE; // Use platform-specific macro
        P.denoise = typeof denoise === "number" ? denoise : 0.50; // Use passed value or default to 0.50
        P.detail = 0.15;

        if (!P.executeOn(view)) {
            throw new Error("NoiseXTerminator execution failed.");
        }

        console.noteln("NoiseXTerminator applied successfully with denoise =", P.denoise);
    } catch (error) {
        console.criticalln("Error applying NoiseXTerminator:", error.message || error);
        new MessageBox("NoiseXTerminator failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
    }
}

function AstroImageDetailDialog() {
   this.__base__ = Dialog;
   this.__base__();
   this.windowTitle = "Astro Image Detail";

this.debounceTimer = null; // Timer to delay preview updates
this.debounceDelay = 300;  // Delay in milliseconds (adjust as needed)
   this.title = new Label(this);
   this.title.text = "Astro Image Detail";
   this.title.textAlignment = TextAlign_Center;
   this.title.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
   this.title.minHeight = 40;
   this.title.maxHeight = 50;

   this.description = new TextBox(this);
this.description.text =
   "Select your stretched image from the dropdown to begin sharpening\n\n" +
   "For best results, please use a stretched, starless image\n\n" +
   "Move Large Structure slider to increase or decrease large structure sharpening.\n" +
   "5 is a good starting point for both OSC and Mono.\n\n" +
   "Move Small Structure slider to increase or decrease small structure sharpening\n" +
   "OSC: 1 is a good starting point.\n" +
   "Mono 2x Drizzle: 5 is a good starting point.\n\n" +
   "Select Apply NoiseXterminator and set the denoise strength to reduce created noise.\n" +
   "Note that NoiseXterminator is required for this function to operate.\n\n" +
   "Written by Tony De Nardo";

this.description.readOnly = true;
this.description.minHeight = 400; // Adjust height for better spacing
this.description.minWidth = 400;

// Set background, alignment, font size, and font family to Sans-serif
this.description.styleSheet =
   "background-color: #d3d3d3;" + // Grey background color
   "font-size: 8pt;" +          // Slightly larger font
   "font-family: Sans-serif;" +  // Sans-serif font
   "text-align: center;" +       // Center the text
   "padding: 10px;";             // Add padding for better readability

   // Find the active window
   let activeWindow = ImageWindow.activeWindow;
   if (!activeWindow.isNull) {
      AstroImageDetailParameters.targetView = activeWindow.mainView;
   } else {
      AstroImageDetailParameters.targetView = null;
   }

   // add a view picker
   this.viewList = new ViewList(this);
   this.viewList.getAll();
   if (AstroImageDetailParameters.targetView) {
      this.viewList.currentView = AstroImageDetailParameters.targetView;
   }
   this.viewList.onViewSelected = function(view) {
      AstroImageDetailParameters.targetView = view;
   };

   // create the input slider for Large Scale Structure
   this.LargeScaleControl = new NumericControl(this);
   this.LargeScaleControl.label.text = "Large Scale Structure:";
   this.LargeScaleControl.label.width = 120;
   this.LargeScaleControl.setRange(0, 8);
   this.LargeScaleControl.setPrecision(2);
   this.LargeScaleControl.slider.setRange(0, 100);
   this.LargeScaleControl.setValue(AstroImageDetailParameters.LargeScale); // Set the default value
   this.LargeScaleControl.toolTip = "<p>Adjust above 5 with caution.</p>";
   this.LargeScaleControl.onValueUpdated = function(value) {
   AstroImageDetailParameters.LargeScale = value;
}.bind(this);

// Updated createAndDisplayTemporaryImage for preview
AstroImageDetailDialog.prototype.createAndDisplayTemporaryImage = function(selectedImage) {
   let window = new ImageWindow(
      selectedImage.width, selectedImage.height,
      selectedImage.numberOfChannels,
      selectedImage.bitsPerSample,
      selectedImage.isReal,
      selectedImage.isColor
   );

   window.mainView.beginProcess();
   window.mainView.image.assign(selectedImage);
   window.mainView.endProcess();

   // Use the global scope explicitly to call applyMLT
   if (typeof applyMLT === "function") {
      applyMLT(window.mainView, AstroImageDetailParameters.LargeScale);
   } else {
      console.criticalln("Error: applyMLT function is not defined.");
   }

   // Resize for preview display
   var resample = new IntegerResample;
   resample.zoomFactor = -4; // Default zoom for preview
   resample.executeOn(window.mainView);

   let resizedImage = new Image(window.mainView.image);
   window.forceClose();

   return resizedImage;
};

// Adjusted onValueUpdated for the slider
this.LargeScaleControl.onValueUpdated = function(value) {
   AstroImageDetailParameters.LargeScale = value;
}.bind(this);

   this.SmallScaleStructureControl = new NumericControl(this);
this.SmallScaleStructureControl.label.text = "Small Scale Structure:";
this.SmallScaleStructureControl.label.width = 120;
this.SmallScaleStructureControl.setRange(0, 8);
this.SmallScaleStructureControl.setPrecision(2);
this.SmallScaleStructureControl.slider.setRange(0, 100);
this.SmallScaleStructureControl.setValue(AstroImageDetailParameters.SmallScale);
this.SmallScaleStructureControl.toolTip = "<p>Adjust the small scale structure amount.</p>";
this.SmallScaleStructureControl.onValueUpdated = function (value) {
   AstroImageDetailParameters.SmallScale = value;
   }.bind(this);

// Add NoiseXTerminator checkbox
this.noiseXTerminatorCheckBox = new CheckBox(this);
this.noiseXTerminatorCheckBox.text = "Apply NoiseXTerminator";
this.noiseXTerminatorCheckBox.checked = false; // Default unchecked
this.noiseXTerminatorCheckBox.toolTip = "<p>Enable this option to apply NoiseXTerminator after sharpening.</p>";
this.noiseXTerminatorCheckBox.onCheck = function(checked) {
   AstroImageDetailParameters.applyNoiseXTerminator = checked;
}.bind(this);

// Add Denoise slider for NoiseXTerminator
this.DenoiseControl = new NumericControl(this);
this.DenoiseControl.label.text = "Denoise Strength:";
this.DenoiseControl.label.width = 120;
this.DenoiseControl.setRange(0, 1.0); // Slider range from 0 to 1.0
this.DenoiseControl.setPrecision(2); // Two decimal places
this.DenoiseControl.slider.setRange(0, 100); // Slider resolution
this.DenoiseControl.setValue(AstroImageDetailParameters.denoise || 0.50); // Default value for P.denoise
this.DenoiseControl.toolTip = "<p>Adjust the denoise strength for NoiseXTerminator.</p>";

// Update the parameter when the slider value changes
this.DenoiseControl.onValueUpdated = function (value) {
   // Update the denoise value in parameters without triggering a preview update
   AstroImageDetailParameters.denoise = value;
   }.bind(this);

   // Add create instance button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = () => {
      // stores the parameters
      AstroImageDetailParameters.save();
      // create the script instance
      this.newInstance();
   };

   // Create zoom dropdown
   // Create zoom dropdown
this.zoomLabel = new Label(this);
this.zoomLabel.text = "Zoom: ";
this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

this.zoomComboBox = new ComboBox(this);
this.zoomComboBox.addItem("1:1");
this.zoomComboBox.addItem("1:2");
this.zoomComboBox.addItem("1:4");
this.zoomComboBox.addItem("1:8");
this.zoomComboBox.addItem("Fit to Preview");
this.zoomComboBox.currentItem = 2; // Set default to "1:4"
this.zoomComboBox.minWidth = 120; // Set minimum width
this.zoomComboBox.onItemSelected = (index) => {
   let zoomFactor;
   switch (index) {
      case 0: zoomFactor = -1; break; // 1:1
      case 1: zoomFactor = -2; break; // 1:2
      case 2: zoomFactor = -4; break; // 1:4
      case 3: zoomFactor = -8; break; // 1:8
      case 4: // Fit to Preview
         const previewWidth = this.previewControl.viewport.width;
         const imageWidth = this.previewControl.getImage() ? this.previewControl.getImage().width : 1;
         zoomFactor = -Math.max(1, Math.floor(imageWidth / previewWidth));
         break;
      default: zoomFactor = -4; // Default to 1:4
   }

   // Update zoom factor and refresh preview
   this.previewControl.zoomFactor = zoomFactor;
   if (AstroImageDetailParameters.showPreview) {
      this.refreshPreview();
   }
};

// Update refreshPreview to use the zoomFactor
AstroImageDetailDialog.prototype.refreshPreview = function () {
   if (AstroImageDetailParameters.showPreview && AstroImageDetailParameters.targetView) {
      let sourceImage = AstroImageDetailParameters.targetView.image;

      // Create a temporary window for combined processing
      let tempWindow = new ImageWindow(
         sourceImage.width, sourceImage.height,
         sourceImage.numberOfChannels,
         sourceImage.bitsPerSample,
         sourceImage.isReal,
         sourceImage.isColor
      );

      tempWindow.mainView.beginProcess();
      tempWindow.mainView.image.assign(sourceImage); // Copy the source image
      tempWindow.mainView.endProcess();

      // Apply MLT for large-scale sharpening
      if (AstroImageDetailParameters.LargeScale > 0) {
         applyMLT(tempWindow.mainView, AstroImageDetailParameters.LargeScale);
      } else {
         console.noteln("LargeScale is set to 0, skipping MLT.");
      }

      // Apply MMT for small-scale sharpening
      if (AstroImageDetailParameters.SmallScale > 0) {
         applyMMT(tempWindow.mainView, AstroImageDetailParameters.SmallScale);
      } else {
         console.noteln("SmallScale is set to 0, skipping MMT.");
      }

           // Apply NoiseXTerminator if enabled
      if (AstroImageDetailParameters.applyNoiseXTerminator) {
         console.noteln(
            "Applying NoiseXTerminator in preview with denoise =",
            AstroImageDetailParameters.denoise
         );
         applyNoiseXTerminator(tempWindow.mainView, AstroImageDetailParameters.denoise);
       } else {
         console.noteln("NoiseXTerminator not applied in preview as checkbox is unchecked.");
      }

      // Resize for preview display using the zoom factor
      let resample = new IntegerResample();
      resample.zoomFactor = this.previewControl.zoomFactor || -4; // Default to 1:4
      resample.executeOn(tempWindow.mainView);

      // Convert the temporary window's image to a new Image object
      let previewImage = new Image(tempWindow.mainView.image);

      // Update the preview control
      this.previewControl.doUpdateImage(previewImage);

      // Close the temporary window
      tempWindow.forceClose();
   }
};

// Create preview refresh button
this.previewRefreshButton = new PushButton(this);
this.previewRefreshButton.text = "Refresh Preview";
this.previewRefreshButton.minWidth = 120; // Set minimum width
this.previewRefreshButton.onClick = () => {
   this.refreshPreview();
};

   // Create a sizer for zoom controls and refresh button
this.zoomSizer = new HorizontalSizer;
this.zoomSizer.margin = 4;
this.zoomSizer.spacing = 4;
this.zoomSizer.add(this.zoomLabel);
this.zoomSizer.add(this.zoomComboBox);
this.zoomSizer.addSpacing(12);
this.zoomSizer.add(this.previewRefreshButton);

   // prepare the execution button
   this.execButton = new PushButton(this);
   this.execButton.text = "Execute";
   this.execButton.width = 80; // Increased width
   this.execButton.onClick = () => {
      this.applySharpeningToMainImage();
      this.ok();
   };

   // create a horizontal slider to layout the execution button
   this.execButtonSizer = new HorizontalSizer;
   this.execButtonSizer.margin = 8;
   this.execButtonSizer.add(this.newInstanceButton)
   this.execButtonSizer.addSpacing(12);
   this.execButtonSizer.add(this.zoomSizer);
   this.execButtonSizer.addStretch();
   this.execButtonSizer.add(this.execButton)

   // Create a preview control
   this.previewControl = new ScrollControl(this);
   this.previewControl.setMinWidth(300);  // Set minimum width to avoid taking too much space
   this.previewControl.setMinHeight(300); // Set minimum height
   this.previewControl.visible = false;   // Hide preview control initially

   // layout the dialog
this.leftSizer = new VerticalSizer;
this.leftSizer.margin = 8;
this.leftSizer.spacing = 8;
this.leftSizer.add(this.title);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.description);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.viewList);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.LargeScaleControl);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.SmallScaleStructureControl);
this.leftSizer.addSpacing(8);

// Add NoiseXTerminator checkbox
this.leftSizer.add(this.noiseXTerminatorCheckBox);
this.leftSizer.addSpacing(8); // Add spacing after the checkbox

// Add DenoiseControl slider
this.leftSizer.add(this.DenoiseControl);
this.leftSizer.addSpacing(8); // Add spacing after the slider

// Create the checkbox for Show Preview
this.showPreviewCheckBox = new CheckBox(this);
this.showPreviewCheckBox.text = "Show Preview";
this.showPreviewCheckBox.checked = AstroImageDetailParameters.showPreview;
this.showPreviewCheckBox.toolTip = "<p>Enable or disable preview of the stretch.</p>";
this.showPreviewCheckBox.onCheck = function (checked) {
   AstroImageDetailParameters.showPreview = checked;
   this.previewControl.visible = checked; // Ensure preview visibility toggles correctly
   this.zoomSizer.visible = checked;

   if (checked && AstroImageDetailParameters.targetView) {
      this.refreshPreview(); // Update preview when checked
   }

   this.adjustToContents();
}.bind(this);

// Add Show Preview checkbox
this.leftSizer.add(this.showPreviewCheckBox);
this.leftSizer.addSpacing(8);

// Add Show Preview checkbox
this.leftSizer.add(this.showPreviewCheckBox);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.execButtonSizer);
this.leftSizer.addStretch();
this.leftSizer.minWidth = 300; // Set minimum width for left sizer

   this.mainSizer = new HorizontalSizer;
   this.mainSizer.margin = 8;
   this.mainSizer.spacing = 8;
   this.mainSizer.add(this.leftSizer);
   this.mainSizer.add(this.previewControl, 1, Align_Expand);  // Ensure preview control gets allocated proper space

   this.sizer = this.mainSizer;

   this.adjustToContents();

   this.onShow = () => {
      this.previewControl.visible = false;
      this.zoomSizer.visible = false;
      this.adjustToContents();
   };

   this.createAndDisplayTemporaryImage = function(selectedImage) {
   let window = new ImageWindow(
      selectedImage.width, selectedImage.height,
      selectedImage.numberOfChannels,
      selectedImage.bitsPerSample,
      selectedImage.isReal,
      selectedImage.isColor
   );

   window.mainView.beginProcess();
   window.mainView.image.assign(selectedImage);
   window.mainView.endProcess();

   // Apply MLT for preview using the global applyMLT function
   applyMLT(window.mainView, AstroImageDetailParameters.LargeScale);

   // Resize for preview display
   var resample = new IntegerResample;
   resample.zoomFactor = -4; // Default zoom for preview
   resample.executeOn(window.mainView);

   let resizedImage = new Image(window.mainView.image);
   window.forceClose();

   return resizedImage;
};

   this.adjustToContents();
}

AstroImageDetailDialog.prototype = new Dialog;


AstroImageDetailDialog.prototype.applySharpeningToMainImage = function () {
   if (AstroImageDetailParameters.targetView) {
      console.noteln("Target view detected. Processing...");

      // Apply MLT for large-scale sharpening
      if (AstroImageDetailParameters.LargeScale > 0) {
         console.noteln("Applying MLT with LargeScale =", AstroImageDetailParameters.LargeScale);
         applyMLT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.LargeScale);
      } else {
         console.noteln("LargeScale is set to 0, skipping MLT.");
      }

      // Apply MMT for small-scale sharpening
      if (AstroImageDetailParameters.SmallScale > 0) {
         console.noteln("Applying MMT with SmallScale =", AstroImageDetailParameters.SmallScale);
         applyMMT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.SmallScale);
      } else {
         console.noteln("SmallScale is set to 0, skipping MMT.");
      }

      // Apply NoiseXTerminator if enabled
      if (AstroImageDetailParameters.applyNoiseXTerminator) {
         console.noteln(
            "NoiseXTerminator is enabled. Applying with denoise =",
            AstroImageDetailParameters.denoise
         );
         applyNoiseXTerminator(AstroImageDetailParameters.targetView, AstroImageDetailParameters.denoise); // Pass the current denoise value
      } else {
         console.noteln("NoiseXTerminator not applied as checkbox is unchecked.");
      }

     console.noteln("Processing completed successfully!");
   } else {
      console.warningln("No target view is specified.");
   }
};

AstroImageDetailDialog.prototype.refreshPreview = function() {
   if (AstroImageDetailParameters.showPreview && AstroImageDetailParameters.targetView) {
      let sourceImage = AstroImageDetailParameters.targetView.image;

      // Create a temporary window for combined processing
      let tempWindow = new ImageWindow(
         sourceImage.width, sourceImage.height,
         sourceImage.numberOfChannels,
         sourceImage.bitsPerSample,
         sourceImage.isReal,
         sourceImage.isColor
      );

      tempWindow.mainView.beginProcess();
      tempWindow.mainView.image.assign(sourceImage); // Copy the source image
      tempWindow.mainView.endProcess();

      // Apply MLT for large-scale sharpening
      if (AstroImageDetailParameters.LargeScale > 0) {
         applyMLT(tempWindow.mainView, AstroImageDetailParameters.LargeScale);
      } else {
         console.noteln("LargeScale is set to 0, skipping MLT.");
      }

      // Apply MMT for small-scale sharpening
      if (AstroImageDetailParameters.SmallScale > 0) {
         applyMMT(tempWindow.mainView, AstroImageDetailParameters.SmallScale);
       } else {
         console.noteln("SmallScale is set to 0, skipping MMT.");
      }

      // Resize for preview display
      let resample = new IntegerResample;
      resample.zoomFactor = -4; // Default zoom for preview
      resample.executeOn(tempWindow.mainView);

      // Convert the temporary window's image to a new Image object
      let previewImage = new Image(tempWindow.mainView.image);

      // Update the preview control
      this.previewControl.doUpdateImage(previewImage);

      // Close the temporary window
      tempWindow.forceClose();
   }
};

AstroImageDetailDialog.prototype.createTemporaryImage = function(selectedImage) {
   let window = new ImageWindow(
      selectedImage.width,
      selectedImage.height,
      selectedImage.numberOfChannels,
      selectedImage.bitsPerSample,
      selectedImage.isReal,
      selectedImage.isColor
   );

   window.mainView.beginProcess();
   window.mainView.image.assign(selectedImage);
   window.mainView.endProcess();

   var P = new IntegerResample;
   switch (this.zoomComboBox.currentItem) {
      case 0:
         P.zoomFactor = -1;
         break;
      case 1:
         P.zoomFactor = -2;
         break;
      case 2:
         P.zoomFactor = -4;
         break;
      case 3:
         P.zoomFactor = -8;
         break;
      case 4:
         const previewWidth = this.previewControl.width;
         const widthScale = Math.floor(selectedImage.width / previewWidth);
         P.zoomFactor = -Math.max(widthScale, 1);
         break;
      default:
         P.zoomFactor = -2;
         break;
   }

   P.executeOn(window.mainView);

   let resizedImage = new Image(window.mainView.image);

   if (resizedImage.width > 0 && resizedImage.height > 0) {
      this.previewControl.displayImage = resizedImage;
      this.previewControl.doUpdateImage(resizedImage);
      this.previewControl.initScrollBars();
   } else {
      console.error("Resized image has invalid dimensions.");
   }

   window.forceClose();

   return resizedImage;
};

// Function to check if the view is grayscale
function isGrayscale(view) {
   return !view.image.isColor;
}

function run() {
   if (AstroImageDetailParameters.targetView) {
      console.noteln("Processing target view:", AstroImageDetailParameters.targetView.fullId);

      // Apply MLT for large-scale sharpening
      if (AstroImageDetailParameters.LargeScale > 0) {
         console.noteln("Applying MLT with LargeScale =", AstroImageDetailParameters.LargeScale);
         applyMLT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.LargeScale);
      } else {
         console.noteln("LargeScale is set to 0, skipping MLT.");
      }

      // Apply MMT for small-scale sharpening
      if (AstroImageDetailParameters.SmallScale > 0) {
         console.noteln("Applying MMT with SmallScale =", AstroImageDetailParameters.SmallScale);
         applyMMT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.SmallScale);
      } else {
         console.noteln("SmallScale is set to 0, skipping MMT.");
      }

      // Apply NoiseXTerminator if enabled
      if (AstroImageDetailParameters.applyNoiseXTerminator) {
         console.noteln(
            "NoiseXTerminator is enabled. Applying with denoise =",
            AstroImageDetailParameters.denoise
         );
         applyNoiseXTerminator(AstroImageDetailParameters.targetView, AstroImageDetailParameters.denoise);
      } else {
         console.noteln("NoiseXTerminator not applied as checkbox is unchecked.");
      }

      console.noteln("Processing completed successfully!");
   } else {
      console.warningln("No target view specified. Aborting.");
   }
}

// Main execution logic
function main() {
   if (Parameters.isGlobalTarget) {
      // If the new instance is double-clicked, open the dialog
      if (Parameters.has("LargeScale") || Parameters.has("SmallScale") || Parameters.has("showPreview")) {
         // Load parameters if they exist
         console.noteln("Double-click detected: Loading parameters and opening Astro Image Detail GUI...");
         AstroImageDetailParameters.load();
      } else {
         console.noteln("Double-click detected: No parameters found. Opening Astro Image Detail GUI...");
      }
      let dialog = new AstroImageDetailDialog();
      dialog.execute();
      return;
   }

   if (Parameters.isViewTarget) {
      // If the new instance is dropped on a view, run the script on the target view
      console.noteln("New instance dragged onto a view: Running script...");
      AstroImageDetailParameters.load();
      if (!Parameters.targetView.isNull) {
         AstroImageDetailParameters.targetView = Parameters.targetView;
         run(); // Execute the script with the current parameters
      } else {
         console.warningln("The target view is invalid.");
      }
      return;
   }

   // For direct execution, open the dialog
   let dialog = new AstroImageDetailDialog();
   dialog.execute();
}

main();
