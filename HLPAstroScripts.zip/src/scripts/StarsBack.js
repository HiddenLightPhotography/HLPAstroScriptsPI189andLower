#feature-id   StarsBack : HLP > Stars Back
#feature-info A script to add unscreened stars back to the image.

#include <pjsr/StdButton.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>

// Function to apply PixelMath
function applyPixelMath(dsoView, starsView, originalDsoName, originalStarsName) {
   var P = new PixelMath;
  P.expression = "~(~$T*~$T_stars)";
  P.expression1 = "";
  P.expression2 = "";
  P.expression3 = "";
  P.useSingleExpression = true;
  P.symbols = "";
  P.clearImageCacheAndExit = false;
  P.cacheGeneratedImages = false;
  P.generateOutput = true;
  P.singleThreaded = false;
  P.optimization = true;
  P.use64BitWorkingImage = false;
  P.rescale = false;
  P.rescaleLower = 0;
  P.rescaleUpper = 1;
  P.truncate = true;
  P.truncateLower = 0;
  P.truncateUpper = 1;
  P.createNewImage = true;
  P.showNewImage = true;
  P.newImageId = originalDsoName + "_StarsBack";
  P.newImageWidth = 0;
  P.newImageHeight = 0;
  P.newImageAlpha = false;
  P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
  P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

  P.executeOn(dsoView);

// Restore the original names of the views
    dsoView.id = originalDsoName;
    starsView.id = originalStarsName;
}

function SimplePixelMathDialog() {
  this.__base__ = Dialog;
  this.__base__();

  // Initialize the main sizer for the dialog
  this.sizer = new VerticalSizer;
  this.sizer.margin = 6;
  this.sizer.spacing = 4;

  // Title label
  this.titleLabel = new Label(this);
  this.titleLabel.text = "Stars Back";
  this.titleLabel.textAlignment = TextAlign_Center;
  this.titleLabel.font = new Font("SansSerif", 20);
  this.sizer.add(this.titleLabel);
  this.sizer.addSpacing(8);

  // Instruction area with a visible box
  this.instructionGroupBox = new GroupBox(this);
  this.instructionGroupBox.title = "Instructions";
  this.instructionGroupBox.sizer = new VerticalSizer;
  this.instructionGroupBox.sizer.margin = 6;
  this.instructionGroupBox.sizer.spacing = 4;

  // Instruction label with instructions text
  this.instructionLabel = new Label(this.instructionGroupBox);
  this.instructionLabel.text = "Please select your DSO (Deep Sky Object) image and select your stars image and click Execute.\n" +
                               "The script will then add the stars back into your image:\n" +
                               "The script will automatically handle image window names for you.\n\n" +
                               "Important Note:\n" +
                               "This is for stretched images\n\n" +
                               "Written by Tony De Nardo";
  this.instructionLabel.textAlignment = TextAlign_Center;
  this.instructionGroupBox.sizer.add(this.instructionLabel);
  this.sizer.add(this.instructionGroupBox);
  this.sizer.addSpacing(8);

// Add a label above the radio buttons
this.radioButtonLabel = new Label(this);
this.radioButtonLabel.text = "Please select your stars image type:";
this.radioButtonLabel.textAlignment = TextAlign_Left; // Align the label to the left
this.sizer.add(this.radioButtonLabel);
this.sizer.addSpacing(4); // Add a small space below the label

  // Radio buttons for selecting image type
this.starsOnlyRadio = new RadioButton(this);
this.starsOnlyRadio.text = "Stars Only Image";
this.starsOnlyRadio.checked = false; // Not selected by default

this.unscreenedStarsRadio = new RadioButton(this);
this.unscreenedStarsRadio.text = "Unscreened Stars";
this.unscreenedStarsRadio.checked = true; // Selected by default

// Vertical sizer to stack the radio buttons
let radioButtonSizer = new VerticalSizer;
radioButtonSizer.spacing = 4;

// Switch the order here
radioButtonSizer.add(this.unscreenedStarsRadio); // Unscreened Stars first
radioButtonSizer.add(this.starsOnlyRadio); // Stars Only Image second

this.sizer.add(radioButtonSizer);

// Add space between radio buttons and the DSO dropdown
this.sizer.addSpacing(8); // Adjust the value for the desired spacing

  // Label and dropdown for selecting the active DSO view
  this.dsoLabel = new Label(this);
  this.dsoLabel.text = "Select DSO Image:";
  this.dsoLabel.textAlignment = TextAlign_Left;

  this.dsoViewList = new ViewList(this);
  this.dsoViewList.getAll();
  this.dsoViewList.nullViewText = "Select DSO Image";

  let dsoSizer = new HorizontalSizer;
  dsoSizer.spacing = 4;
  dsoSizer.add(this.dsoLabel);
  dsoSizer.add(this.dsoViewList, 100);
  this.sizer.add(dsoSizer);

  // Label and dropdown for selecting the active Stars view
  this.starsLabel = new Label(this);
  this.starsLabel.text = "Select Stars Image:";
  this.starsLabel.textAlignment = TextAlign_Left;

  this.starsViewList = new ViewList(this);
  this.starsViewList.getAll();
  this.starsViewList.nullViewText = "Select Stars Image";

  let starsSizer = new HorizontalSizer;
  starsSizer.spacing = 4;
  starsSizer.add(this.starsLabel);
  starsSizer.add(this.starsViewList, 100);
  this.sizer.add(starsSizer);

  this.sizer.addSpacing(8);

  // Execute button to apply PixelMath to both views
this.execButton = new PushButton(this);
this.execButton.text = "Execute";
this.execButton.onClick = function() {
    var dsoView = this.dsoViewList.currentView;
    var starsView = this.starsViewList.currentView;

    if (dsoView != null && starsView != null) {
        // Save the original names
        var originalDsoName = dsoView.id;
        var originalStarsName = starsView.id;

        // Temporarily rename the views for PixelMath
        dsoView.id = "DSO";
        starsView.id = "DSO_stars";

        // Determine which PixelMath expression to use based on the selected radio button
        if (this.unscreenedStarsRadio.checked) {
            // Apply the current PixelMath: ~(~$T * ~$T_stars)
            applyPixelMath(dsoView, starsView, originalDsoName, originalStarsName);
            Console.writeln("PixelMath applied: ~(~$T * ~$T_stars)");
        } else if (this.starsOnlyRadio.checked) {
            // Apply the new PixelMath: DSO + DSO_stars
            var P = new PixelMath();
            P.expression = "DSO+DSO_stars";
            P.expression1 = "";
            P.expression2 = "";
            P.expression3 = "";
            P.useSingleExpression = true;
            P.symbols = "";
            P.clearImageCacheAndExit = false;
            P.cacheGeneratedImages = false;
            P.generateOutput = true;
            P.singleThreaded = false;
            P.optimization = true;
            P.use64BitWorkingImage = false;
            P.rescale = false;
            P.rescaleLower = 0;
            P.rescaleUpper = 1;
            P.truncate = true;
            P.truncateLower = 0;
            P.truncateUpper = 1;
            P.createNewImage = true;
            P.showNewImage = true;
            P.newImageId = originalDsoName + "_StarsBack";
            P.newImageWidth = 0;
            P.newImageHeight = 0;
            P.newImageAlpha = false;
            P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
            P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
            P.executeOn(dsoView);

            Console.writeln("PixelMath applied: DSO + DSO_stars");
        }

        // Restore the original names of the views
        dsoView.id = originalDsoName;
        starsView.id = originalStarsName;
    } else {
        Console.warningln("Both DSO and Stars images must be selected.");
    }
}.bind(this);

  this.sizer.add(this.execButton);

  this.windowTitle = "Stars Back v1.0.1";
}

SimplePixelMathDialog.prototype = new Dialog;

function main() {
  // Run the dialog
  var dialog = new SimplePixelMathDialog();
  dialog.execute();
}

main();
